# Key de prueba SENSI OG

- Key: `SENSI-OG-2026`
- Tipo: activación local de prueba dentro de la app.
- Duración: 30 días desde que se introduce por primera vez en ese dispositivo.
- Permisos: desbloquea la sesión de usuario/menú de patches para probar la pantalla de acceso.
- No requiere servidor para probar la activación local.
- El catálogo remoto y las descargas de patches NO funcionan con esta clave hasta publicar y configurar la API.
- Esta clave está incluida en el código de la app y puede extraerse del binario. Es solo para pruebas; no usar como licencia de producción ni subirla como secreto.
- Para validar Keys reales generadas por Telegram, la API debe estar publicada y la app debe tener configurada `PantherAPIBaseURL`.
